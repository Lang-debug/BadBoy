package musicPlayer;
import java.awt.BorderLayout;  
import java.awt.Color;
import java.awt.Container;  
import java.awt.Font;
import java.awt.Toolkit;  
import java.awt.event.ActionEvent;  
import java.awt.event.ActionListener;  
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;  
import javax.swing.JFrame;  
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSlider;
import javax.swing.WindowConstants;  
  
public class Musicplayer extends JFrame
{  
     
    
    
    
    private MusicPlay playthread; 
    
    JPanel mainPanel=new JPanel();
    
    JButton playbutton,next; 
    JButton pre;
    //��ͣ״̬
    boolean pause=true;
    //���ڲ���״̬
    boolean playing=false;
    
    String list[];
    
    JLabel songName;  
    
    int index=0;
    
    /**
     * ���캯��
     */
    public Musicplayer()
    {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(300, 60, 600, 430);
        this.setBackground(Color.WHITE);
        this.setResizable(false);
        mainPanel.setLayout(null);
        mainPanel.setSize(600, 400);
        mainPanel.setBackground(Color.WHITE);
        this.add(mainPanel);
        
        //���ֳ�ʼ��
        playthread=new MusicPlay();
        File file = new File("musiclist"); 
        list= file.list();
        
        playthread.setFile("musiclist\\"+list[0]);
        
        playbutton = new JButton();
        playbutton.setFocusable(false);
        playbutton.setBorderPainted(false);
        playbutton.setBackground(Color.WHITE);
        playbutton.setOpaque(false);
        playbutton.setIcon(new ImageIcon("img\\����_1.png"));
        playbutton.setOpaque(false);
        playbutton.setBounds(284,330,32,32);  
        //�������л�ͼƬ
        playbutton.addMouseListener(new MouseAdapter()
        {
        	public void mousePressed(MouseEvent e) 
        	{
        		if(!playing)
        		{
        			playbutton.setIcon(new ImageIcon("img\\����.png"));
        			
        		}
        		else
        		{
        			if(pause)
        				playbutton.setIcon(new ImageIcon("img\\����.png"));
        			else
        				playbutton.setIcon(new ImageIcon("img\\��ͣ.png"));
        		}
        		
        	}
        	public void mouseReleased(MouseEvent e) 
        	{
        		if(!playing)
        		{
        			playbutton.setIcon(new ImageIcon("img\\��ͣ_1.png"));
        			playthread.setStop(false);
        			playthread.setPause(false);
        			playthread.start();
        			playing=true;
        			pause=false;
        		}
        		else
        		{
        			if(pause)
        			{
        				//���˲���״̬
        				playbutton.setIcon(new ImageIcon("img\\��ͣ_1.png"));
        				playthread.setPause(false);
        				if(!playthread.isAlive())
        				{
        					System.out.println("��ʼ����");
        					playthread.start();
        				}
        				pause=!pause;
        			}
        			else
        			{
        				//������ͣ״̬
        				playbutton.setIcon(new ImageIcon("img\\����_1.png"));
        				playthread.setPause(true);
        				pause=!pause;
        			}
        		}
        		songName.setText(list[index]);
        	}
        	
        });
        
        pre = new JButton();
        pre.setFocusable(false);
        pre.setBorderPainted(false);
        pre.setBackground(Color.WHITE);
        pre.setIcon(new ImageIcon("img\\��ͷ ��.png"));
        pre.setBounds(204,331,32,32);
        pre.addMouseListener(new MouseAdapter()
        {
        	public void mouseReleased(MouseEvent e)
        	{
        		if(index-1>=0)
        		{
        			index--;
        			System.out.println(list[index]);
        			playthread.setStop(true);
        			playthread=new MusicPlay();
        			playthread.setFile("musiclist\\"+list[index]);
        			if(!pause)
        				playthread.start();
        			
        		}
        		else if(index==0)
        		{
        			index=list.length-1;
        			System.out.println(list[index]);
        			playthread.setStop(true);
        			playthread=new MusicPlay();
        			playthread.setFile("musiclist\\"+list[index]);
        			if(!pause)
        				playthread.start();
        		}
        		songName.setText(list[index]);
        	}
        	
        });
        
        
        next = new JButton();
        next.setFocusable(false);
        next.setBorderPainted(false);
        next.setBackground(Color.WHITE);
        next.setIcon(new ImageIcon("img\\��ͷ ��.png"));
        next.setBounds(363,329,32,32);
        next.addMouseListener(new MouseAdapter()
        {
        	public void mouseReleased(MouseEvent e)
        	{
        		if((index+2)<=list.length)
        		{
        			index++;
        			System.out.println(list[index]);
        			playthread.setStop(true);
        			playthread=new MusicPlay();
        			playthread.setFile("musiclist\\"+list[index]);
        			if(!pause)
        				playthread.start();
        		}
        		else if(index==list.length-1)
        		{
        			index=0;
        			System.out.println(list[index]);
        			playthread.setStop(true);
        			playthread=new MusicPlay();
        			playthread.setFile("musiclist\\"+list[index]);
        			if(!pause)
        				playthread.start();
        			
        		}
        		songName.setText(list[index]);
        	}
        });
        
        songName=new JLabel(list[0]);
        songName.setFont(new Font("΢���ź�",Font.PLAIN,23));
        songName.setHorizontalAlignment(JLabel.CENTER);
        songName.setBounds(60,250,480,50);
        
        JLabel logo=new JLabel(new ImageIcon("img\\logo.png"));
        logo.setBounds(200,45,200,200);
        
        mainPanel.add(logo);
        mainPanel.add(playbutton); 
        mainPanel.add(pre);
        mainPanel.add(next);
        mainPanel.add(songName);
        
        this.setVisible(true);  
    }  
      
    
    /**
     * ˢ�¸���
     */
    
    /** 
     * @param args ������
     */  
    public static void main(String[] args) 
    {
    	//TODO �������
    	new Musicplayer();  
    }  
}  



package musicPlayer;  
import javax.sound.sampled.AudioFormat;  
import javax.sound.sampled.AudioSystem;  
import javax.sound.sampled.SourceDataLine;  
import javax.sound.sampled.LineUnavailableException;  
  
import java.io.RandomAccessFile;  
  
import java.util.Scanner;  
  

public class PlayBackThread extends Thread
{  
    private SourceDataLine dataline;  
    private final int dataOffset = 0x2e;  
    
@Override  
    public void run()
	{  
        try
        {  
           RandomAccessFile raf = new RandomAccessFile("musiclist\\��ϧ��+-+�׶�1801.wav","r");  
           AudioFormat af;  
           af = new AudioFormat(44100,16,2,true,false);  
           dataline = (SourceDataLine)AudioSystem.getSourceDataLine(af);  
           dataline.open(af);  
           raf.seek(dataOffset);  
           int hasRead=0;  
           dataline.start();  
           byte[] buff=new byte[4096];  
           Scanner input = new Scanner(System.in);  
           while((hasRead=raf.read(buff))>0)
           {  
        	   //print(raf.getFilePointer(),buff);  
               dataline.write(buff, 0, hasRead);  
           }  
           dataline.stop();  
        } catch(Exception e){  
            e.printStackTrace();  
        }  
    }  
        public static void print(long pointer, byte[] buff){  
            System.out.format("%x: " ,pointer);  
            System.out.format("%x ", buff[0]);  
            System.out.format("%x ", buff[1]);  
            System.out.format("%x ", buff[2]);  
            System.out.format("%x ", buff[3]);  
              
            System.out.println();  
    }  
}